package com.grupo3ex5.argprograma.trabajointegradortramo2;

import com.grupo3ex5.argprograma.trabajointegradortramo2.Servicios.ManipularBD;

/**
 *
 * @author Grupo 3
 */
public class TrabajoIntegradorTramo2 {

    public static void main(String[] args) {
        ManipularBD modTablas = new ManipularBD();

        modTablas.mostrarTablas();

        modTablas.CargaInicial();
        
        modTablas.mostrarTablas();
    }

}
